import numpy as np
import matplotlib.pyplot as plt

# Step 1: Data
x = np.array([100, 200, 300, 400, 500])
y = np.array([50, 90, 120, 160, 190])

# Step 2: Manual Linear Regression
n = len(x)
sum_x = np.sum(x)
sum_y = np.sum(y)
sum_xy = np.sum(x * y)
sum_x_squared = np.sum(x ** 2)

# Calculate slope (m) and intercept (b)
m = (n * sum_xy - sum_x * sum_y) / (n * sum_x_squared - sum_x ** 2)
b = (sum_y - m * sum_x) / n

# Print slope and intercept
print(f"Slope (m): {m}")
print(f"Intercept (b): {b}")

# Step 3: Prediction for new visitor count (e.g., 600 visitors)
new_visitors = 600
predicted_revenue = m * new_visitors + b
print(f"Predicted revenue for {new_visitors} visitors: ${predicted_revenue:.2f}")

# Step 4: Plotting
plt.scatter(x, y, color='blue', label='Actual Data')
plt.plot(x, m * x + b, color='red', label=f'Regression Line: y = {m:.2f}x + {b:.2f}')

# Plot the predicted point
plt.scatter(new_visitors, predicted_revenue, color='green', marker='x', s=100, label=f'Predicted for {new_visitors} visitors')

# Add labels and legend
plt.title("Daily Visitors vs. Ad Revenue")
plt.xlabel("Daily Visitors")
plt.ylabel("Advertising Revenue ($)")
plt.legend()
plt.grid(True)
plt.tight_layout()

# Show plot
plt.show()
