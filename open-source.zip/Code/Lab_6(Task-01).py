import numpy as np
units_sold = np.array([
    [50, 60],  # Monday
    [45, 55],  # Tuesday
    [60, 70],  # Wednesday
    [65, 75],  # Thursday
    [80, 90],  # Friday
    [85, 95],  # Saturday
    [90, 100]  # Sunday
])
prices = np.array([15, 20])  # Region A: $15, Region B: $20

revenue_per_day = units_sold * prices  # Element-wise multiplication
total_revenue_per_region = revenue_per_day.sum(axis=0)

average_sales_per_day = units_sold.mean(axis=0)

highest_sales_day_region_a = np.argmax(units_sold[:, 0])
highest_sales_day_region_b = np.argmax(units_sold[:, 1])
days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

total_company_revenue = revenue_per_day.sum()

print("Total Revenue per Region:")
print(f"Region A: ${total_revenue_per_region[0]}")
print(f"Region B: ${total_revenue_per_region[1]}")

print("\nAverage Sales per Day:")
print(f"Region A: {average_sales_per_day[0]:.2f} units")
print(f"Region B: {average_sales_per_day[1]:.2f} units")

print("\nDay with Highest Sales:")
print(f"Region A: {days[highest_sales_day_region_a]} ({units_sold[highest_sales_day_region_a, 0]} units)")
print(f"Region B: {days[highest_sales_day_region_b]} ({units_sold[highest_sales_day_region_b, 1]} units)")

print(f"\nTotal Company Revenue: ${total_company_revenue}")
