class Employee:
    def __init__(self, name, id_number, salary,department):
        self.name = name
        self.id_number = id_number
        self.salary = salary
        self.department = department

    def display_employee_info(self):
        print(f"Name: {self.name}")
        print(f"ID Number: {self.id_number}")
        print(f"Salary: {self.salary}")
        print(f"Department: {self.department}")

class Manager(Employee):
    def __init__(self, name, id_number, salary, department, team_size=0):
        super().__init__(name, id_number, salary, department)
        self.team_size = team_size
        self.team_members = []

    def add_team_member(self, member_name):
        print(f"Adding {member_name} to the team.")
        self.team_members.append(member_name)
        self.team_size= len(self.team_members)

    def remove_team_member(self, member_name):
        if member_name in self.team_members:
            print(f"Removing {member_name} from the team.")
            self.team_members.remove(member_name)
            self.team_size= len(self.team_members)
        else:
            print(f"{member_name} is not in the team.")

    def update_salary(self, new_salary):
        self.salary = new_salary
        print(f"Salary updated to: {self.salary}")

    def display_manager_info(self):
        super().display_employee_info()
        print(f"Team Size: {self.team_size}")
        print(f"Team Members: {', '.join(self.team_members)}")

emp1= Employee("Alice", "E001", 50000, "HR")
emp1.display_employee_info()
print()
emp2= Manager("Bob", "M001", 80000, "IT")
emp2.add_team_member("Charlie")
emp2.add_team_member("David")
emp2.display_manager_info()
print()
emp2.remove_team_member("Charlie")
emp2.update_salary(85000)
emp2.display_manager_info()