products= ['Apple','Banana','Orange','Milk','Egg']
quantities=[10,2,0,15,4]

for i in range(len(products)):
    if 5 > quantities[i] > 0:
        print(f"{products[i]} needs restocking")
    elif quantities[i] == 0:
        print(f"{products[i]} out of stock")
total_item= sum(quantities)
print(f"Total Item: {total_item}")
