class BankAccount:
    class Transaction:
        def __init__(self, transaction_id, transaction_type, amount, date):
            self.transaction_id = transaction_id
            self.transaction_type = transaction_type
            self.amount = amount
            self.date = date

        def __str__(self):
            return f"Transaction ID: {self.transaction_id}, Type: {self.transaction_type}, Amount: ${self.amount}, Date: {self.date}"

    def __init__(self, account_holder, account_number, balance, account_type):
        self.account_holder = account_holder
        self.account_number = account_number
        self.balance = balance
        self.account_type = account_type
        self.transactions = []

    def __str__(self):
        return f"Account Holder: {self.account_holder}, Account Type: {self.account_type}, Balance: ${self.balance}"

    def deposit(self, amount):
        self.balance += amount
        print(f"${amount} deposited. New balance: ${self.balance}")

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
            print(f"${amount} withdrawn. New balance: ${self.balance}")
        else:
            print("Insufficient balance.")

    def get_balance(self):
        return self.balance

    def add_transaction(self, transaction):
        self.transactions.append(transaction)
        print("Transaction added.")

account = BankAccount("John Doe", "1234567890", 1000.0, "Checking")
print(account)
account.deposit(200)
account.withdraw(150)

txn1 = BankAccount.Transaction("T001", "Deposit", 200, "2025-05-21")
account.add_transaction(txn1)

print(txn1)

account.account_type = "Savings"
print("Updated account type:", account.account_type)

del account.account_number
print("account_number property deleted.")

del account
print("BankAccount object deleted.")
