#Task --> 03
import pandas as pd
import matplotlib.pyplot as plt

data = {
    'Car_ID': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'EngineSize': [1.6, 2.0, 1.8, 2.5, 3.0, 1.4, 1.6, 2.2, 2.0, 1.8],
    'Horsepower': [120, 150, 140, 200, 250, 100, 110, 180, 160, 130],
    'FuelConsumption': [30, 25, 28, 20, 18, 35, 32, 22, 24, 27]
}


df = pd.DataFrame(data)

plt.figure(figsize=(8, 6))
plt.scatter(df['EngineSize'], df['FuelConsumption'], color='blue', alpha=0.7)

plt.title('Fuel Consumption vs Engine Size')
plt.xlabel('Engine Size (Liters)')
plt.ylabel('Fuel Consumption (MPG)')

plt.grid(True)

plt.show()
