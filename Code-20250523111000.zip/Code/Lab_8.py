
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

df= pd.read_csv('/content/FuelConsumptionCo2.csv')

x= df[['FUELCONSUMPTION_CITY']].values
y= df['CO2EMISSIONS'].values

x_train, x_test, y_train, y_test= train_test_split(x, y, test_size= 0.2, random_state= 0)

x_train_b= np.c_[np.ones((x_train.shape[0], 1)), x_train]
x_test_b= np.c_[np.ones((x_test.shape[0], 1)), x_test]

theta= np.linalg.inv(x_train_b.T.dot(x_train_b)).dot(x_train_b.T).dot(y_train)
c= theta[0]
m= theta[1]

print(f"Computed Model: y = {m:.4f}x + {c:.4f}")

y_predict= x_test_b.dot(theta)

mse= mean_squared_error(y_test, y_predict)
print(f"Mean Squared Error: {mse:.4f}")

plt.figure(figsize=(17, 7))
plt.title('Fuel Consumption vs CO2 Emissions')
plt.xlabel('Fuel Consumption (City)')
plt.ylabel('CO2 Emissions')
plt.scatter(x_train, y_train, color='green', label='Training Data',alpha=0.6)
plt.scatter(x_test, y_test, color='blue', label='Testing Data', alpha=0.6)
plt.plot(x_test, y_predict, color='red', linewidth=2, label='Predicted Line')
plt.legend()
plt.grid(True)
plt.show()