import numpy as np

# Coefficient matrix A
A = np.array([
    [3, 2, 1],
    [2, 4, 3],
    [1, 1, 2]
])

# Constant matrix B
B = np.array([1, 2, 3])

# Calculate the inverse of A
A_inv = np.linalg.inv(A)

# Solve for X
X = np.dot(A_inv, B)

print("Solution (x, y, z):", X)
