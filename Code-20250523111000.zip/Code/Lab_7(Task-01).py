import pandas as pd

# Step 1: Create the dataset
data = {
    'StudentID': [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Fahim', 'Grace', 'Hannah', 'Ivy', 'John'],
    'Subject': ['Math', 'Programming', 'Algorithm', 'Math', 'Programming', 'Algorithm', 'Math', 'Programming', 'Algorithm', 'Math'],
    'Score': [92, 85, 78, 67, 59, 95, 88, 73, 81, 60]
}

df = pd.DataFrame(data)

# Step 2: Find average score for each subject
avg_scores = df.groupby('Subject')['Score'].mean()

# Step 3: Find the highest and lowest score in the dataset
highest_score = df['Score'].max()
lowest_score = df['Score'].min()

# Step 4: Add a new column 'Grade'
def calculate_grade(score):
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'

df['Grade'] = df['Score'].apply(calculate_grade)

# Step 5: Count the number of students who got an 'A' in each subject
a_count = df[df['Grade'] == 'A'].groupby('Subject')['Grade'].count()

# Output results
print("Original DataFrame:\n", df)
print("\nAverage Score for Each Subject:\n", avg_scores)
print("\nHighest Score in Dataset:", highest_score)
print("Lowest Score in Dataset:", lowest_score)
print("\nNumber of Students with Grade A in Each Subject:\n", a_count)
