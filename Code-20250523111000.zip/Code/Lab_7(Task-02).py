import pandas as pd
df= pd.read_csv('/content/FuelConsumptionCo2.csv')

df.head(5)

df.tail(5)

df.describe()

df.info()

df.mean(numeric_only=True)

df.median(numeric_only=True)

df.max(numeric_only=True)

df.min(numeric_only=True)

df.count()

df.sum(numeric_only=True)

df.std(numeric_only=True)

df.var(numeric_only=True)

df.fillna(0)

df.dropna()

df.dropna(axis=1)

df.sort_values(by='MODEL', ascending=True)

df.sort_values(by='MODEL', ascending=False)

df.groupby("MAKE")["CO2EMISSIONS"].mean()

df.pivot_table(values="FUELCONSUMPTION_COMB", index="VEHICLECLASS", columns="TRANSMISSION", aggfunc="mean")

df['CO2EMISSIONS'].apply(lambda x: x/1.609)

