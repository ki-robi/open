#Task-01
def make_album(artist, tittle, num_song=None):
    album={
        'artist': artist,
        'tittle': tittle
    }
    if num_song is not None:
        album['songs']= num_song
    return album
album_1= make_album("Atif Aslam", "Jal", 7)
album_2= make_album("Ed Sheeran","Perfect" )
print(album_1)
print(album_2)

#Task-02
def make_car(manufacturer, model, **kwargs):
    car = {
        'manufacturer': manufacturer,
        'model': model
    }
    for key, value in kwargs.items():
        car[key] = value
    return car
car = make_car('subaru', 'outback', color='blue', tow_package=True)
print(car)

