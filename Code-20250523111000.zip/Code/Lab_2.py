def get_inventory():
    inventory = {}
    print("Enter items for inventory (type 'exit' to stop)")
    while True:
        item = input("Enter item name: ")
        if item.lower() == "exit":
            break
        try:
            price = float(input("Enter price: "))
            quantity = int(input("Enter quantity: "))
            inventory[item] = [price, quantity]
        except ValueError:
            print("Invalid input. Please enter numeric values for price and quantity.")
    return inventory


def maintain(inventory):
    while True:
        print("\nDo you want to update, delete or print?")
        user = input('Your choice: ').strip().lower()

        if user == "update":
            item = input("Item name: ")
            if item in inventory:
                try:
                    price = float(input("New price: "))
                    quantity = int(input("New quantity: "))
                    inventory[item] = [price, quantity]
                    print(f"{item} updated.")
                except ValueError:
                    print("Invalid input. Price must be a number and quantity an integer.")
            else:
                print("Item not found in inventory.")

        elif user == "delete":
            item = input("Item name: ")
            if item in inventory:
                del inventory[item]
                print(f"{item} deleted from inventory.")
            else:
                print("Item not found.")

        elif user == "print":
            if not inventory:
                print("Inventory is empty.")
            else:
                print(f"\n{'Item':<12}{'Price':>10}{'Quantity':>12}")
                print("-" * 34)
                for item, (price, quantity) in inventory.items():
                    print(f"{item:<12}${price:>9.2f}{quantity:>12}")

        else:
            print("Invalid option. Please choose update, delete or print.")


# Run the program
inventory = get_inventory()
maintain(inventory)
