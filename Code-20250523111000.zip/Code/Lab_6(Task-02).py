import numpy as np
grades = np.array([
    [85, 90, 78],   # Student 1
    [88, 76, 92],   # Student 2
    [75, 85, 89],   # Student 3
    [90, 93, 91],   # Student 4
    [82, 87, 85]    # Student 5
])
# Task 1: Total grades per student (sum along axis 1)
total_per_student = grades.sum(axis=1)

# Task 2: Average grade per subject (mean along axis 0)
average_per_subject = grades.mean(axis=0)

# Task 3: Highest grade per subject (max along axis 0)
highest_per_subject = grades.max(axis=0)

print("1. Total Grades for Each Student:")
for i, total in enumerate(total_per_student, start=1):
    print(f"Student {i}: {total}")

print("\n2. Average Grade for Each Subject:")
subjects = ['Subject 1', 'Subject 2', 'Subject 3']
for subject, avg in zip(subjects, average_per_subject):
    print(f"{subject}: {avg:.2f}")

print("\n3. Highest Grade in Each Subject:")
for subject, high in zip(subjects, highest_per_subject):
    print(f"{subject}: {high}")
